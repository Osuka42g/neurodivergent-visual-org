---
name: mermaid-drawio-google-drawings
description: Use when mermaid diagrams need professional editing in Google Docs with full draw.io integration - exports to PNG/SVG/draw.io, uploads to Drive folders, enables editing in diagrams.net and embedding as Google Drawings
metadata:
  created: 2025-11-05
  version: 1.0.0
---

# Mermaid → Draw.io → Google Drawings Workflow

## Overview

**Professional editable diagrams for Google Docs collaboration.**

This workflow enables mermaid diagrams to be edited in draw.io and embedded as Google Drawings, allowing non-technical collaborators to modify diagrams directly in Google Docs.

## When to Use

Use when:
- Diagrams need to be editable by non-technical collaborators
- Professional presentation quality required
- Multiple export formats needed (PNG, SVG, draw.io)
- Google Docs is primary collaboration environment
- Diagrams will be updated frequently by team members

Don't use when:
- Quick PNG export is sufficient (use `syncing-diagrams-to-google-drive` skill instead)
- No collaboration needed
- Local-only work
- Diagrams are simple and rarely change

## Critical Lesson

**NEVER abandon comprehensive plans for "simpler" approaches without testing first.**

This workflow was initially abandoned for a PNG-only approach, which missed the core requirement (editable diagrams in Google Docs). User caught the mistake and commanded: "Follow the plan and make sure you never make this mistake again."

**Always follow comprehensive plans completely, test, then simplify if truly needed.**

## Architecture

### Complete Pipeline

```
Markdown with mermaid blocks
    ↓
mermaid-export.py (extracts & exports)
    ↓
PNG (2400x1600) + SVG (scalable) + draw.io (editable)
    ↓
gdrive-diagram-handler.py (uploads to organized folders)
    ↓
Google Drive folders (Technical Diagrams, Move Planning Diagrams, etc.)
    ↓
Open .drawio in diagrams.net web app
    ↓
Import SVG for editing
    ↓
Save as Google Drawing
    ↓
Embed in Google Docs (Insert > Drawing > From Drive)
```

### Tools Overview

**4 Production-Ready Tools in `claude/tools/`:**

1. **`mermaid-export.py`** (417 lines) - Extract & export
2. **`gdrive-diagram-handler.py`** (288 lines) - Google Drive upload
3. **`convert-diagrams.sh`** (156 lines) - Batch processing
4. **`diagram-status.py`** (89 lines) - Status dashboard

## Quick Start

### Export All Diagrams

```bash
# Export to PNG/SVG/draw.io (no upload)
./claude/tools/convert-diagrams.sh --export-only
```

### Upload to Google Drive

```bash
# Full pipeline: export + upload
./claude/tools/convert-diagrams.sh
```

### Check Status

```bash
# View all exports with timestamps
python3 claude/tools/diagram-status.py
```

## Detailed Workflow

### Step 1: Configure Diagrams

Edit `claude/tools/convert-diagrams.sh`:

```bash
declare -a DIAGRAMS=(
    "file_path:diagram_index:drive_folder:output_basename"
    "efforts/current/move/flowcharts.md:0:Move Planning Diagrams:master-flowchart"
    "claude/agents/architecture.md:0:Technical Diagrams:system-architecture"
)
```

Format: `markdown_file:diagram_index:google_drive_folder:output_name`

### Step 2: Export Diagrams

```bash
# Export single diagram
python3 claude/tools/mermaid-export.py export \
  --file "path/to/file.md" \
  --diagram-index 0

# Export all configured diagrams
./claude/tools/convert-diagrams.sh --export-only
```

**Creates 3 files per diagram:**
- `diagram-name.png` - High-resolution raster (2400x1600)
- `diagram-name.svg` - Scalable vector graphics
- `diagram-name.drawio` - Editable XML template

**Exports saved to:** `{source-dir}/exports/`

### Step 3: Upload to Google Drive

```bash
# Upload single diagram set
python3 claude/tools/gdrive-diagram-handler.py upload \
  --export-dir "path/to/exports" \
  --folder-name "Technical Diagrams" \
  --base-name "diagram-name"

# Upload all configured diagrams
./claude/tools/convert-diagrams.sh
```

**Creates organized folders in Google Drive:**
- Technical Diagrams (for architecture docs)
- Move Planning Diagrams (for decision flowcharts)
- Custom folders as configured

### Step 4: Edit in Draw.io (Optional)

After upload, you'll receive a draw.io link:

```
Open in draw.io: https://app.diagrams.net/#G{file_id}
```

**Editing workflow:**
1. Click the draw.io link
2. Select "Open from Google Drive"
3. Choose your .drawio file
4. Import the SVG when prompted
5. Edit as needed
6. File > Save As > Google Drawing
7. Close draw.io

### Step 5: Embed in Google Docs

In Google Docs:
1. Insert > Drawing > From Drive
2. Select your PNG (quick) or Google Drawing (editable)
3. Resize as needed
4. Done!

**PNG vs Drawing:**
- **PNG**: Fast, static, good for final presentations
- **Google Drawing**: Editable in Google Docs, good for collaboration

## Key Features

### Change Detection

Diagrams are hashed (MD5) to avoid unnecessary re-exports:

```bash
# Check what needs updating
python3 claude/tools/mermaid-export.py status
```

Manifest tracks:
- Last export timestamp
- Content hash
- Available formats
- Diagram index

### Manifest Tracking

**Export manifest** (`.mermaid-export/manifest.json`):
```json
{
  "path/to/file.md": {
    "last_export": "2025-11-05T01:41:00Z",
    "formats": ["png", "svg", "drawio"],
    "hash": "b4d4bba7",
    "diagram_index": 0
  }
}
```

**Upload manifest** (`{export-dir}/{basename}-gdrive-manifest.json`):
```json
{
  "folder_id": "1q7vPDMbFc...",
  "files": {
    "png": {
      "id": "1CdM0szpSc...",
      "link": "https://drive.google.com/...",
      "embed": {
        "google_docs": "Image ID: 1CdM0szpSc...",
        "markdown": "![Diagram](https://drive.google.com/uc?id=...)",
        "html": "<img src=\"...\" alt=\"Diagram\">"
      }
    },
    "drawio": {
      "id": "1gVtnCuBQ...",
      "embed": {
        "open_in_drawio": "https://app.diagrams.net/#G1gVtnCuBQ...",
        "google_docs": "Draw.io file ID: ... (Insert > Drawing > From Drive)"
      }
    }
  }
}
```

### Batch Processing

Process multiple diagrams efficiently:

```bash
# Export only (fast, no network)
./claude/tools/convert-diagrams.sh --export-only

# Upload only (assumes already exported)
./claude/tools/convert-diagrams.sh --upload-only

# Full pipeline
./claude/tools/convert-diagrams.sh
```

Color-coded output shows progress:
- 🎨 Blue: Exporting
- ☁️  Cyan: Uploading
- ✅ Green: Success
- ❌ Red: Failure

## Common Patterns

### Pattern 1: Add New Diagram

```bash
# 1. Add to convert-diagrams.sh
vim claude/tools/convert-diagrams.sh

# Add line to DIAGRAMS array:
# "path/to/file.md:0:Folder Name:output-name"

# 2. Export and upload
./claude/tools/convert-diagrams.sh
```

### Pattern 2: Update Existing Diagram

```bash
# 1. Edit mermaid source in markdown
vim path/to/file.md

# 2. Re-export (change detection auto-detects)
./claude/tools/convert-diagrams.sh --export-only

# 3. Check what changed
python3 claude/tools/diagram-status.py

# 4. Upload if needed
./claude/tools/convert-diagrams.sh --upload-only
```

### Pattern 3: Collaborate on Diagram

```bash
# 1. Export and upload to Drive
./claude/tools/convert-diagrams.sh

# 2. Share draw.io link from manifest
cat exports/diagram-name-gdrive-manifest.json | grep open_in_drawio

# 3. Collaborator edits in draw.io
# (they open link, edit, save as Google Drawing)

# 4. They embed in Google Docs
# (Insert > Drawing > From Drive)
```

### Pattern 4: Bulk Status Check

```bash
# View all exports
python3 claude/tools/diagram-status.py

# List all diagrams in vault
python3 claude/tools/mermaid-export.py list

# Check specific file
python3 claude/tools/mermaid-export.py status \
  --file "path/to/file.md"
```

## Tool Reference

### mermaid-export.py

**Purpose:** Extract mermaid blocks from markdown and export to multiple formats.

**Commands:**
```bash
# List all mermaid diagrams in vault
python3 claude/tools/mermaid-export.py list

# Export specific diagram
python3 claude/tools/mermaid-export.py export \
  --file "path/to/file.md" \
  --diagram-index 0

# Check export status
python3 claude/tools/mermaid-export.py status
```

**Key Features:**
- Extracts mermaid blocks using regex
- Exports to PNG (high-res), SVG (scalable), draw.io (editable)
- MD5 content hashing for change detection
- Manifest tracking in `.mermaid-export/manifest.json`

### gdrive-diagram-handler.py

**Purpose:** Upload diagram sets to organized Google Drive folders.

**Commands:**
```bash
# Create folder structure
python3 claude/tools/gdrive-diagram-handler.py create-folders

# Upload diagram set
python3 claude/tools/gdrive-diagram-handler.py upload \
  --export-dir "path/to/exports" \
  --folder-name "Technical Diagrams" \
  --base-name "diagram-name"
```

**Key Features:**
- Reuses google-drive-sync.py authentication (shared token)
- Creates/finds folders in Google Drive
- Uploads PNG, SVG, draw.io with proper MIME types
- Generates embed codes for Google Docs
- Saves manifest with file IDs and links

### convert-diagrams.sh

**Purpose:** Batch process all configured diagrams.

**Commands:**
```bash
# Export only (no upload)
./claude/tools/convert-diagrams.sh --export-only

# Upload only (assumes exported)
./claude/tools/convert-diagrams.sh --upload-only

# Full pipeline (export + upload)
./claude/tools/convert-diagrams.sh
```

**Configuration:**
Edit diagram array in script:
```bash
declare -a DIAGRAMS=(
    "file:index:folder:basename"
)
```

### diagram-status.py

**Purpose:** View export status dashboard.

**Command:**
```bash
python3 claude/tools/diagram-status.py
```

**Output:**
```
🎨 Mermaid Diagram Export Status

╭───────────────┬─────────┬──────────────┬──────────────┬──────╮
│ Source File   │ Diagram │ Last Export  │ Formats      │ Hash │
├───────────────┼─────────┼──────────────┼──────────────┼──────┤
│ claude/...md  │ #0      │ 2025-11-05   │ png,svg,dio  │ b4d4 │
╰───────────────┴─────────┴──────────────┴──────────────┴──────╯
```

## Agent Integration

### For Vault-Organizer

When vault-organizer detects mermaid diagrams in Google Drive-synced files:

```python
# Check if diagram workflow needed
if file_has_mermaid_diagrams and syncs_to_google_drive:
    recommend_skill("mermaid-drawio-google-drawings")
```

### For Scribe

When Scribe updates diagrams in planning documents:

```python
# After updating mermaid in markdown
if diagram_changed:
    # Re-export automatically
    run("./claude/tools/convert-diagrams.sh --export-only")
```

### For Transition/Move Planning Agents

When creating visual decision flowcharts:

```python
# After creating mermaid flowchart
if needs_google_docs_collaboration:
    use_skill("mermaid-drawio-google-drawings")
else:
    use_skill("syncing-diagrams-to-google-drive")  # Simple PNG
```

## Troubleshooting

### Export Fails

**Symptom:** `mmdc: command not found`

**Fix:**
```bash
# Install mermaid-cli
npm install -g @mermaid-js/mermaid-cli

# Verify
mmdc --version
```

### Upload Fails

**Symptom:** `Authentication error` or `Credentials not found`

**Fix:**
```bash
# Re-authenticate (uses google-drive-sync.py credentials)
rm ~/.config/gdrive-sync/token.pickle
python3 claude/agents/transition/google-drive-sync.py status
# Follow OAuth flow
```

### Draw.io Link Doesn't Open

**Symptom:** "File not found" in draw.io

**Fix:**
1. Check file ID in manifest: `cat exports/*-gdrive-manifest.json`
2. Verify file exists in Google Drive
3. Check sharing permissions
4. Try direct link: `https://drive.google.com/file/d/{file_id}/view`

## Related Skills

- **`syncing-diagrams-to-google-drive`** - Simple PNG-only workflow (faster, simpler)
- Use this skill when: Professional editing not needed, quick exports sufficient

## Documentation

**Complete workflow guide:** `claude/tools/README.md`
**Session log with lesson learned:** `claude/sessions/2025-11-04-draw-io-workflow-complete.md`
**Tool documentation:** Each script has `--help` flag

## Success Criteria

This workflow is successful when:
- ✅ Non-technical collaborators can edit diagrams in Google Docs
- ✅ No HTTP 500 errors when syncing large markdown files
- ✅ Diagrams available in multiple formats (PNG, SVG, draw.io)
- ✅ Change detection prevents unnecessary re-exports
- ✅ Organized Google Drive folders make files findable
- ✅ Mermaid source remains in markdown as source of truth

## Real-World Impact

**Before:**
- HTTP 500 errors on large markdown files
- Diagrams not editable by collaborators
- Manual export/upload process
- No change tracking

**After:**
- 5 diagrams exported to 3 formats (15 files)
- Google Drive folders organized
- Professional editing enabled
- 2-minute full pipeline execution
- Change detection via content hashing

**Time saved:** ~30 minutes per diagram update cycle
**Collaboration enabled:** Non-technical team members can edit diagrams
**Reliability:** Zero HTTP 500 errors after implementation
